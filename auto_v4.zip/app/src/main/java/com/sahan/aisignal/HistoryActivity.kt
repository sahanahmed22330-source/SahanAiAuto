package com.sahan.aisignal

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var stats: TextView
    private lateinit var learn: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var lastSig = ""
    private var visible = false

    private val refresher = object : Runnable {
        override fun run() {
            if (!visible) return
            render(false)
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(appBg())
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(30), dp(16), dp(24))
        sv.addView(col)
        setContentView(sv)

        col.addView(tv("Results & History", 22f, 0xFFFFFFFF.toInt(), true))
        stats = tv("", 13f, 0xFF00E5FF.toInt(), true)
        stats.setPadding(0, dp(8), 0, dp(4))
        col.addView(stats)
        col.addView(tv("WIN / LOSS is marked automatically after the next candle closes (green candle = UP won, red candle = DOWN won). You can tap WIN or LOSS to correct a result.", 11f, 0xAAFFFFFF.toInt()))
        learn = tv("", 11f, 0xCCFFFFFF.toInt())
        learn.setPadding(0, dp(6), 0, dp(8))
        col.addView(learn)

        val clear = tv("🗑  Clear all", 13f, 0xFFFFFFFF.toInt(), true)
        clear.gravity = Gravity.CENTER
        clear.setPadding(0, dp(10), 0, dp(10))
        clear.background = rounded(0x22FFFFFF, dp(12).toFloat(), dp(1), 0x44FFFFFF)
        clear.setOnClickListener {
            Store.clear(this)
            render(true)
        }
        col.addView(clear, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val reset = tv("🧠 Reset AI learning", 13f, 0xFFFFFFFF.toInt(), true)
        reset.gravity = Gravity.CENTER
        reset.setPadding(0, dp(10), 0, dp(10))
        reset.background = rounded(0x22FFFFFF, dp(12).toFloat(), dp(1), 0x44FFFFFF)
        reset.setOnClickListener {
            Store.resetWeights(this)
            Analyzer.weights = emptyMap()
        }
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(8)
        col.addView(reset, rlp)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
    }

    override fun onResume() {
        super.onResume()
        visible = true
        render(true)
        handler.postDelayed(refresher, 2000)
    }

    override fun onPause() {
        visible = false
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun render(force: Boolean) {
        val h = Store.history(this)
        val nowMs = System.currentTimeMillis()
        val w = h.count { it.result == 1 }
        val l = h.count { it.result == 2 }
        val waiting = h.count { it.result == 0 && nowMs - it.time < 150000L }
        val sig = "${h.size}:$w:$l:$waiting:" + (if (h.isEmpty()) 0L else h[0].time)
        if (!force && sig == lastSig) return
        lastSig = sig

        val rate = if (w + l > 0) w * 100 / (w + l) else 0
        val entries = h.count { it.traded }
        learn.text = "🧠 AI learning: ${w + l} marked signals" + (if (w + l < 50) " (needs at least 50 to learn well)" else "") +
            "\nAuto entries placed: $entries"
        stats.text = "Signals ${h.size}  •  Wins $w  •  Losses $l  •  Waiting $waiting  •  Win rate $rate%"
        list.removeAllViews()
        val fmt = SimpleDateFormat("dd MMM  HH:mm:ss", Locale.US)
        for (r in h) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(10), dp(10), dp(10))
            row.background = rounded(0x1FFFFFFF, dp(14).toFloat(), dp(1), 0x33FFFFFF)

            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            val dirColor = if (r.up) 0xFF69F0AE.toInt() else 0xFFFF8A80.toInt()
            left.addView(tv((if (r.up) "▲ UP" else "▼ DOWN") + "  •  ${tfLabel(r.tf)}  •  ${r.conf}%", 14f, dirColor, true))
            val sub = fmt.format(Date(r.time)) +
                (if (r.traded) "  •  AUTO ENTRY" else "") +
                (if (r.result == 0 && nowMs - r.time < 150000L) "  •  waiting for result..." else "")
            left.addView(tv(sub, 11f, 0x99FFFFFF.toInt()))
            row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            row.addView(mark("✔ WIN", r.result == 1, 0xFF00C853.toInt()) {
                Store.setResult(this, r.time, 1)
                Analyzer.weights = Store.weights(this)
                render(true)
            })
            row.addView(mark("✘ LOSS", r.result == 2, 0xFFFF1744.toInt()) {
                Store.setResult(this, r.time, 2)
                Analyzer.weights = Store.weights(this)
                render(true)
            })
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            list.addView(row, lp)
        }
        if (h.isEmpty()) list.addView(tv("No signals yet", 13f, 0x99FFFFFF.toInt()))
    }

    private fun mark(label: String, active: Boolean, color: Int, onClick: () -> Unit): TextView {
        val t = tv(label, 12f, 0xFFFFFFFF.toInt(), true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        t.background = if (active) rounded(color, dp(10).toFloat()) else rounded(0x22FFFFFF, dp(10).toFloat(), dp(1), 0x44FFFFFF)
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(6)
        t.layoutParams = lp
        return t
    }
}
