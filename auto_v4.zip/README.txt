Sahan Ai Auto v4 - Auto Entry works on its own, minimum strength 1-100%, WIN/LOSS marked automatically.
Upload the newest auto_vN.zip to the repo root; the workflow unzips the highest version and builds the APK.
