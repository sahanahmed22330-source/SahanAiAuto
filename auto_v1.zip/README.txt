Sahan Ai Auto - build with GitHub Actions.
Upload the newest auto_vN.zip to the repo root; the workflow unzips the highest version and builds the APK.
