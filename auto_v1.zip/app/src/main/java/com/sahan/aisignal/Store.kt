package com.sahan.aisignal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Rec(val time: Long, val tf: Int, val up: Boolean, val conf: Int, val result: Int, val keys: String = "")

object Store {
    private fun p(c: Context) = c.getSharedPreferences("sahan_ai_auto", Context.MODE_PRIVATE)

    fun tf(c: Context): Int = p(c).getInt("tf", 60)
    fun setTf(c: Context, v: Int) { p(c).edit().putInt("tf", v).apply() }

    fun auto(c: Context): Boolean = p(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) { p(c).edit().putBoolean("auto", v).apply() }

    fun top(c: Context): Int = p(c).getInt("top2", 14)
    fun setTop(c: Context, v: Int) { p(c).edit().putInt("top2", v).apply() }

    fun bottom(c: Context): Int = p(c).getInt("bottom2", 69)
    fun setBottom(c: Context, v: Int) { p(c).edit().putInt("bottom2", v).apply() }

    // clock offset in tenths of a second
    fun offset(c: Context): Int = p(c).getInt("offset", 0)
    fun setOffset(c: Context, v: Int) { p(c).edit().putInt("offset", v).apply() }

    fun autoTrade(c: Context): Boolean = p(c).getBoolean("autotrade", false)
    fun setAutoTrade(c: Context, v: Boolean) { p(c).edit().putBoolean("autotrade", v).apply() }

    fun minConf(c: Context): Int = p(c).getInt("minconf", 65)
    fun setMinConf(c: Context, v: Int) { p(c).edit().putInt("minconf", v).apply() }

    fun maxTrades(c: Context): Int = p(c).getInt("maxtrades", 10)
    fun setMaxTrades(c: Context, v: Int) { p(c).edit().putInt("maxtrades", v).apply() }

    /** vertical position of the Buy / Sell buttons, percent of screen height */
    fun buyY(c: Context): Int = p(c).getInt("buyy", 91)
    fun setBuyY(c: Context, v: Int) { p(c).edit().putInt("buyy", v).apply() }

    /** how many of the newest marked results in a row are losses */
    fun lossStreak(c: Context): Int {
        var n = 0
        for (r in history(c)) {
            if (r.result == 0) continue
            if (r.result == 2) n++ else break
        }
        return n
    }

    @Synchronized
    fun history(c: Context): MutableList<Rec> {
        val out = ArrayList<Rec>()
        try {
            val a = JSONArray(p(c).getString("hist", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Rec(o.getLong("t"), o.getInt("tf"), o.getBoolean("up"), o.getInt("c"), o.getInt("r"), o.optString("k", "")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(c: Context, l: List<Rec>) {
        val a = JSONArray()
        for (r in l) {
            a.put(JSONObject().put("t", r.time).put("tf", r.tf).put("up", r.up).put("c", r.conf).put("r", r.result).put("k", r.keys))
        }
        p(c).edit().putString("hist", a.toString()).apply()
    }

    @Synchronized
    fun add(c: Context, r: Rec) {
        val l = history(c)
        l.add(0, r)
        while (l.size > 300) l.removeAt(l.size - 1)
        save(c, l)
    }

    @Synchronized
    fun setResult(c: Context, time: Long, res: Int) {
        val l = history(c)
        for (i in l.indices) {
            if (l[i].time != time) continue
            val r = l[i]
            if (r.result == res) break
            val ks = r.keys.split(",").filter { it.isNotEmpty() }
            if (r.result == 1) adjust(c, ks, 1.0 / 1.04) else if (r.result == 2) adjust(c, ks, 1.0 / 0.94)
            if (res == 1) adjust(c, ks, 1.04) else if (res == 2) adjust(c, ks, 0.94)
            l[i] = r.copy(result = res)
            break
        }
        save(c, l)
    }

    @Synchronized
    fun weights(c: Context): Map<String, Double> {
        val m = HashMap<String, Double>()
        try {
            val o = JSONObject(p(c).getString("w", "{}") ?: "{}")
            for (k in o.keys()) m[k] = o.getDouble(k)
        } catch (e: Exception) {
        }
        return m
    }

    @Synchronized
    fun adjust(c: Context, keys: List<String>, factor: Double) {
        val m = HashMap(weights(c))
        for (k in keys) m[k] = ((m[k] ?: 1.0) * factor).coerceIn(0.4, 1.6)
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        p(c).edit().putString("w", o.toString()).apply()
    }

    @Synchronized
    fun resetWeights(c: Context) { p(c).edit().putString("w", "{}").apply() }

    @Synchronized
    fun clear(c: Context) { p(c).edit().putString("hist", "[]").apply() }
}
