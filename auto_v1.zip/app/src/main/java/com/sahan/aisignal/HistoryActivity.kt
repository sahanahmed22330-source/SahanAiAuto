package com.sahan.aisignal

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var stats: TextView
    private lateinit var learn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(appBg())
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(30), dp(16), dp(24))
        sv.addView(col)
        setContentView(sv)

        col.addView(tv("Results & History", 22f, 0xFFFFFFFF.toInt(), true))
        stats = tv("", 13f, 0xFF00E5FF.toInt(), true)
        stats.setPadding(0, dp(8), 0, dp(8))
        col.addView(stats)
        learn = tv("", 11f, 0xCCFFFFFF.toInt())
        learn.setPadding(0, 0, 0, dp(8))
        col.addView(learn)

        val clear = tv("🗑  Clear all", 13f, 0xFFFFFFFF.toInt(), true)
        clear.gravity = Gravity.CENTER
        clear.setPadding(0, dp(10), 0, dp(10))
        clear.background = rounded(0x22FFFFFF, dp(12).toFloat(), dp(1), 0x44FFFFFF)
        clear.setOnClickListener {
            Store.clear(this)
            render()
        }
        col.addView(clear, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val reset = tv("🧠 Reset AI learning", 13f, 0xFFFFFFFF.toInt(), true)
        reset.gravity = Gravity.CENTER
        reset.setPadding(0, dp(10), 0, dp(10))
        reset.background = rounded(0x22FFFFFF, dp(12).toFloat(), dp(1), 0x44FFFFFF)
        reset.setOnClickListener {
            Store.resetWeights(this)
            Analyzer.weights = emptyMap()
        }
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(8)
        col.addView(reset, rlp)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        render()
    }

    private fun render() {
        val h = Store.history(this)
        val w = h.count { it.result == 1 }
        val l = h.count { it.result == 2 }
        val rate = if (w + l > 0) w * 100 / (w + l) else 0
        learn.text = "🧠 AI learning: ${w + l} marked signals" + (if (w + l < 50) " (needs at least 50 to learn well)" else "")
        stats.text = "Total ${h.size}  •  Wins $w  •  Losses $l  •  Win rate $rate%"
        list.removeAllViews()
        val fmt = SimpleDateFormat("dd MMM  HH:mm:ss", Locale.US)
        for (r in h) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(10), dp(10), dp(10))
            row.background = rounded(0x1FFFFFFF, dp(14).toFloat(), dp(1), 0x33FFFFFF)

            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            val dirColor = if (r.up) 0xFF69F0AE.toInt() else 0xFFFF8A80.toInt()
            left.addView(tv((if (r.up) "▲ UP" else "▼ DOWN") + "  •  ${tfLabel(r.tf)}  •  ${r.conf}%", 14f, dirColor, true))
            left.addView(tv(fmt.format(Date(r.time)), 11f, 0x99FFFFFF.toInt()))
            row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            row.addView(mark("✔ WIN", r.result == 1, 0xFF00C853.toInt()) {
                Store.setResult(this, r.time, 1)
                Analyzer.weights = Store.weights(this)
                render()
            })
            row.addView(mark("✘ LOSS", r.result == 2, 0xFFFF1744.toInt()) {
                Store.setResult(this, r.time, 2)
                Analyzer.weights = Store.weights(this)
                render()
            })
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            list.addView(row, lp)
        }
        if (h.isEmpty()) list.addView(tv("No signals yet", 13f, 0x99FFFFFF.toInt()))
    }

    private fun mark(label: String, active: Boolean, color: Int, onClick: () -> Unit): TextView {
        val t = tv(label, 12f, 0xFFFFFFFF.toInt(), true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        t.background = if (active) rounded(color, dp(10).toFloat()) else rounded(0x22FFFFFF, dp(10).toFloat(), dp(1), 0x44FFFFFF)
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(6)
        t.layoutParams = lp
        return t
    }
}
