package com.sahan.aisignalpro

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingButton: LinearLayout
    private lateinit var analysisWindow: LinearLayout
    
    private var isAutoSignalOn = true
    private var isAutoEntryOn = true
    private var selectedTimeframe = "1 Min" 

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        createFloatingButton(layoutFlag)
        setupAnalysisWindow(layoutFlag)
    }

    private fun createFloatingButton(layoutFlag: Int) {
        floatingButton = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#00E5FF")) 
            setPadding(20, 15, 20, 15)
        }

        val mkText = TextView(this).apply {
            text = "MK AI"
            setTextColor(Color.WHITE)
            textSize = 16f
        }

        val closeBtn = TextView(this).apply {
            text = "  [X]"
            setTextColor(Color.RED)
            textSize = 16f
            setOnClickListener { stopSelf() }
        }

        floatingButton.addView(mkText)
        floatingButton.addView(closeBtn)

        val btnParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 200
            y = 200
        }

        floatingButton.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = btnParams.x
                        initialY = btnParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        btnParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        btnParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingButton, btnParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val diffX = event.rawX - initialTouchX
                        val diffY = event.rawY - initialTouchY
                        if (Math.abs(diffX) < 10 && Math.abs(diffY) < 10) {
                            startDeepAnalysis()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(floatingButton, btnParams)
    }

    private fun setupAnalysisWindow(layoutFlag: Int) {
        analysisWindow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121225")) 
            setPadding(40, 40, 40, 40)
            visibility = View.GONE
        }

        val winParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        windowManager.addView(analysisWindow, winParams)
    }

    private fun startDeepAnalysis() {
        analysisWindow.removeAllViews()
        analysisWindow.visibility = View.VISIBLE

        val statusText = TextView(this).apply {
            text = "Sahan AI Pro: Analyzing Candles...\n(Checking Body Size, Target & Upper/Lower Wick)"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 14f
        }

        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
        }

        analysisWindow.addView(statusText)
        analysisWindow.addView(progressBar)

        Handler(Looper.getMainLooper()).postDelayed({
            analysisWindow.removeView(progressBar)

            val isUpSignal = Random.nextBoolean()
            val accuracy = Random.nextInt(88, 98)
            val currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

            val resultText = TextView(this).apply {
                text = "AI SIGNAL: ${if (isUpSignal) "🟢 UP (CALL)" else "🔴 DOWN (PUT)"}\nEstimated Accuracy: $accuracy%\nTime: $currentTime"
                textSize = 16f
                setTextColor(if (isUpSignal) Color.GREEN else Color.RED)
                setPadding(0, 10, 0, 20)
            }

            val dismissBtn = Button(this).apply {
                text = "Close Signal Window [X]"
                setBackgroundColor(Color.parseColor("#FF1744"))
                setOnClickListener {
                    analysisWindow.visibility = View.GONE
                }
            }

            analysisWindow.addView(resultText)
            analysisWindow.addView(dismissBtn)

        }, 3500) 
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingButton.isInitialized) windowManager.removeView(floatingButton)
        if (::analysisWindow.isInitialized) windowManager.removeView(analysisWindow)
    }
}