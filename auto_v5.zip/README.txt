Sahan Ai Auto v5 - Auto Entry independent of Auto Signal, no trade/loss limits, minimum strength 1-100%,
WIN/LOSS marked from the real price (like Quotex), button-on-chart warning.
Upload the newest auto_vN.zip to the repo root; the workflow unzips the highest version and builds the APK.
