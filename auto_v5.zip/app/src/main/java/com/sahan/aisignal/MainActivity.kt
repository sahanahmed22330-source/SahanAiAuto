package com.sahan.aisignal

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var startBtn: TextView
    private lateinit var accBtn: TextView
    private val tfViews = ArrayList<Pair<Int, TextView>>()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(appBg())

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(36), dp(18), dp(30))
        sv.addView(col)
        setContentView(sv)

        val white = 0xFFFFFFFF.toInt()
        val cyan = 0xFF00E5FF.toInt()
        val soft = 0xAAFFFFFF.toInt()

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        val logoLp = LinearLayout.LayoutParams(dp(110), dp(110))
        logoLp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(logo, logoLp)

        val title = tv("Sahan Ai Auto", 26f, white, true)
        title.gravity = Gravity.CENTER
        col.addView(title, full())
        val sub = tv("Live Candle AI Analyzer", 13f, cyan)
        sub.gravity = Gravity.CENTER
        col.addView(sub, full())

        // --- candle time
        val c1 = card()
        c1.addView(tv("Candle Time", 15f, white, true))
        c1.addView(tv("Choose the candle time you are using in Quotex", 11f, soft))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(10), 0, 0)
        for (tf in intArrayOf(5, 10, 60)) {
            val t = tv(tfLabel(tf), 14f, white, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener {
                Store.setTf(this, tf)
                refreshTf()
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(t, lp)
            tfViews.add(Pair(tf, t))
        }
        c1.addView(row)
        col.addView(c1, cardLp())
        refreshTf()

        // --- auto
        val c2 = card()
        val sw = Switch(this)
        sw.text = "Auto Signal"
        sw.setTextColor(white)
        sw.textSize = 16f
        sw.isChecked = Store.auto(this)
        sw.setOnCheckedChangeListener { _, v -> Store.setAuto(this, v) }
        c2.addView(sw)
        c2.addView(tv("When ON, the AI gives the next-candle signal by itself just before the running candle ends. When OFF, tap the floating button to get a signal. Keep the floating button on the Quotex chart screen.", 11f, soft))
        col.addView(c2, cardLp())

        // --- settings
        val c3 = card()
        c3.addView(tv("Settings", 15f, white, true))
        slider(c3, "Chart area - top", 0, 40, Store.top(this), { "$it%" }) { Store.setTop(this, it) }
        slider(c3, "Chart area - bottom", 40, 90, Store.bottom(this), { "$it%" }) { Store.setBottom(this, it) }
        slider(c3, "Clock sync", -30, 30, Store.offset(this), { String.format(Locale.US, "%+.1f s", it / 10.0) }) { Store.setOffset(this, it) }
        c3.addView(tv("The chart area should contain only candles - not the Buy / Sell buttons or the top banner. If the button timer does not match the Quotex candle timer, adjust Clock sync.", 11f, soft))
        col.addView(c3, cardLp())

        // --- auto entry
        val c5 = card()
        c5.addView(tv("Auto Entry (BETA)", 15f, 0xFFFFD54F.toInt(), true))
        val swA = Switch(this)
        swA.text = "Bot taps Buy / Sell by itself"
        swA.setTextColor(white)
        swA.textSize = 15f
        swA.isChecked = Store.autoTrade(this)
        swA.setOnCheckedChangeListener { btn, on ->
            if (on) {
                AlertDialog.Builder(this)
                    .setTitle("Enable Auto Entry?")
                    .setMessage("The bot will place REAL trades with no human check. The signals are NOT proven to win. Use a DEMO account first and only risk money you can afford to lose.\n\nThere is no trade limit and no pause after losses: it keeps trading while Auto Entry is ON.")
                    .setCancelable(false)
                    .setPositiveButton("I understand") { _, _ -> Store.setAutoTrade(this, true) }
                    .setNegativeButton("Cancel") { _, _ -> btn.isChecked = false }
                    .show()
            } else {
                Store.setAutoTrade(this, false)
            }
        }
        c5.addView(swA)
        c5.addView(tv("Auto Entry ON + Auto Signal OFF: tap the floating button - the bot analyses and trades. Auto Entry ON + Auto Signal ON: the bot gives signals and trades by itself. Auto Entry OFF: signal only, no trade. It trades only when the strength is at least your minimum and the Quotex time matches.", 11f, soft))
        slider(c5, "Minimum strength to trade", 1, 100, Store.minConf(this), { "$it%" }) { Store.setMinConf(this, it) }
        slider(c5, "Buy / Sell button height", 80, 98, Store.buyY(this), { "$it%" }) { Store.setBuyY(this, it) }
        accBtn = tv("", 13f, white, true)
        accBtn.gravity = Gravity.CENTER
        accBtn.setPadding(0, dp(12), 0, dp(12))
        accBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find Sahan Ai Auto and turn it ON", Toast.LENGTH_LONG).show()
        }
        val alp = full()
        alp.topMargin = dp(10)
        c5.addView(accBtn, alp)
        c5.addView(tv("There is NO trade limit and NO loss limit: it keeps trading while Auto Entry is ON, so switch it OFF yourself when you want it to stop. It never trades below your minimum strength. Keep the floating button away from the Buy / Sell buttons. Android 13+: if Accessibility is greyed out, open App info > menu > Allow restricted settings.", 11f, 0xFFFFCC80.toInt()))
        col.addView(c5, cardLp())

        // --- start / stop
        startBtn = tv("", 17f, white, true)
        startBtn.gravity = Gravity.CENTER
        startBtn.setPadding(0, dp(16), 0, dp(16))
        startBtn.setOnClickListener {
            if (OverlayService.running) {
                stopService(Intent(this, OverlayService::class.java))
                handler.postDelayed({ refreshStart() }, 400)
            } else {
                startFlow()
            }
        }
        val slp = cardLp()
        slp.topMargin = dp(18)
        col.addView(startBtn, slp)

        val hist = tv("📊  RESULTS & HISTORY", 15f, white, true)
        hist.gravity = Gravity.CENTER
        hist.setPadding(0, dp(14), 0, dp(14))
        hist.background = rounded(0x22FFFFFF, dp(16).toFloat(), dp(1), 0x55FFFFFF)
        hist.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        col.addView(hist, cardLp())

        val c4 = card()
        c4.addView(tv("How to use", 14f, white, true))
        c4.addView(tv("1) Pick the candle time, then tap START FLOATING BUTTON.\n2) Open Quotex with the CANDLE chart (not a line chart). Zoom in a little so candles are big.\n3) The AI starts watching the chart as soon as the button is on screen.\n4) Blue ring + ANALYZING MARKET = the AI can read the chart. Red ring + CAN'T SEE MARKET = it cannot (open the candle chart or fix the chart area). If a screen recorder stops the capture, tap the button once to restart it.\n5) When the running candle has 5-7 seconds left, tap the button. It shows ANALYZING for 3-4 seconds, then the signal.\n6) Strength 50% or more = a valid signal. Below 50% = WEAK, skip it.\n7) Tap X (or the box) to hide the signal after you trade. The small status box (ANALYZING MARKET) can be hidden by tapping it or X; it comes back when the market state changes. When nothing is showing, tap X to remove the button.\n8) WIN / LOSS is marked automatically: the app compares the price at the signal with the price one candle-time later. You can still correct a result in History.\n9) Auto Entry (optional): turn on Accessibility and Auto Entry. With Auto Signal ON the bot signals and trades by itself; with Auto Signal OFF it trades when you tap the floating button. Test on DEMO first.", 12f, 0xCCFFFFFF.toInt()))
        c4.addView(tv("⚠ No signal is ever 100% accurate. Test on a demo account first and never trade money you cannot afford to lose.", 11f, 0xFFFFCC80.toInt()))
        col.addView(c4, cardLp())
    }

    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun cardLp(): LinearLayout.LayoutParams {
        val lp = full()
        lp.topMargin = dp(14)
        return lp
    }

    private fun refreshTf() {
        val cur = Store.tf(this)
        for ((tf, t) in tfViews) {
            t.background = if (tf == cur) gradient(0xFF00B8D4.toInt(), 0xFF7C4DFF.toInt(), dp(12).toFloat())
            else rounded(0x22FFFFFF, dp(12).toFloat(), dp(1), 0x44FFFFFF)
        }
    }

    private fun refreshAcc() {
        val on = TapService.instance != null
        accBtn.text = if (on) "Accessibility: ON ✔" else "Accessibility: OFF - tap to enable"
        accBtn.background = if (on) rounded(0x3300C853, dp(12).toFloat(), dp(1), 0xFF00C853.toInt())
        else rounded(0x33FF1744, dp(12).toFloat(), dp(1), 0xFFFF1744.toInt())
    }

    private fun refreshStart() {
        if (OverlayService.running) {
            startBtn.text = "■  STOP FLOATING BUTTON"
            startBtn.background = gradient(0xFFFF1744.toInt(), 0xFFAD1457.toInt(), dp(16).toFloat())
        } else {
            startBtn.text = "▶  START FLOATING BUTTON"
            startBtn.background = gradient(0xFF00C853.toInt(), 0xFF00B8D4.toInt(), dp(16).toFloat())
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStart()
        refreshAcc()
    }

    private fun slider(card: LinearLayout, title: String, min: Int, max: Int, cur: Int, fmt: (Int) -> String, save: (Int) -> Unit) {
        val label = tv("$title: ${fmt(cur)}", 12f, 0xFFFFFFFF.toInt())
        label.setPadding(0, dp(10), 0, 0)
        card.addView(label)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                val v = p + min
                label.text = "$title: ${fmt(v)}"
                save(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        card.addView(sb)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps', then tap START again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            handler.postDelayed({ refreshStart() }, 700)
            Toast.makeText(this, "Started! Now open Quotex.", Toast.LENGTH_SHORT).show()
        }
    }
}
